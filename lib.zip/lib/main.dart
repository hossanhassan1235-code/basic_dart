void main() {
  print('Hi Dart');
  int num1 = 1;
  double num2 = 1.5;
  String num3 = 'eraasoft';
  String num4 = "a";
  bool num5 = true;
  print(num5);
}

/// dataType
/// 
/// int
/// double
/// string
/// boolean
///
/// dataType varNAME = VALY ;
/// EX  1, 1.5 , eraasoft , true , "a"
///  
// colecctions dataType
// list
// map
// set 