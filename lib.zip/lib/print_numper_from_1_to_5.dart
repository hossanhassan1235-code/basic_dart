void main() {
  print('start app');
  for (int i = 1; i <= 10; i++) {
    print(i);
  }
  print('end app');
}
